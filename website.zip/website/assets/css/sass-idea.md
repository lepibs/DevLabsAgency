main : #37517e
secondary : 
light : #47b2e4
lighter : #e8edf5
dark :
